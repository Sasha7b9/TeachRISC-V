#include "rvl-link.h"

const char *rvl_link_get_name(void)
{
    return "GD32VF103C-START";
}
