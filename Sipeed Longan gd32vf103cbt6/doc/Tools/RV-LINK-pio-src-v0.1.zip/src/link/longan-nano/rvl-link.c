#include "rvl-link.h"

const char *rvl_link_get_name(void)
{
    return "Longan Nano";
}
