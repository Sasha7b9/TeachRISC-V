#ifndef __RVL_LINK_CONFIG_H__
#define __RVL_LINK_CONFIG_H__

//#define RVL_LINK_CONFIG_JTAG_PIN_ALT

#endif // __RVL_LINK_CONFIG_H__
