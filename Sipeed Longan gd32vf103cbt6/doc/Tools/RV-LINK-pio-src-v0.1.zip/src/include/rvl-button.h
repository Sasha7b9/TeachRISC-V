#ifndef __RVL_BUTTON_H__
#define __RVL_BUTTON_H__

void rvl_button_init(void);
/*
 * button pushed return 1 else return 0
 */
int rvl_button_pushed(void);

#endif /* __RVL_BUTTON_H__ */
