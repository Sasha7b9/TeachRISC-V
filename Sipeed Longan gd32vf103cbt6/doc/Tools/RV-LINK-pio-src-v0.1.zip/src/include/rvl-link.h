#ifndef __RVL_LINK_H__
#define __RVL_LINK_H__

const char *rvl_link_get_name(void);

#endif // __RVL_LINK_H__
