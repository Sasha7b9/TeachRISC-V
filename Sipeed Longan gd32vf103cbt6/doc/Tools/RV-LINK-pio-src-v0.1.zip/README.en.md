# RV-LINK

#### Description

RV-LINK: In application debugger for RISC-V microcontrollers, RISC-V emulator, use RISC-V development boards (Longan Nano for example). 

Like [Blackmagic](https://github.com/blacksphere/blackmagic), but designed for RISC-V.
